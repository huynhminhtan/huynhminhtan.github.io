mvn clean
mvn package
docker rm $(docker ps -a -q)

#docker-compose build --no-cache
#docker-compose up --force-recreate
docker-compose build
docker-compose stop
docker-compose rm -f
docker-compose up

