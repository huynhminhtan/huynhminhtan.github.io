package com.minhtan.core;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Vertx;
import org.redisson.Redisson;
import org.redisson.api.RList;
import org.redisson.api.RedissonClient;
import org.redisson.config.Config;

public class OrderVerticle extends AbstractVerticle {

    private static Vertx vertx = null;

    public static Vertx getInstanceVertX() {

        if (vertx == null) {
            vertx = Vertx.vertx();
            vertx.deployVerticle(new OrderVerticle());
        }

        return vertx;
    }

    public static void main(String[] args) {
        Vertx vertx = getInstanceVertX();
        vertx.deployVerticle(new OrderVerticle());

        Config config = new Config();
        config.useSingleServer().setAddress("redis://redis_db:6379");
        RedissonClient redisson = Redisson.create(config);

//        RedissonClient redisson = Redisson.create();

        RList<String> list = redisson.getList("mylist");

        list.add("aaaaaaaaaa");
        System.out.println("Add 'aaaaaaaaaa' to Redis");
        list.add("bbbbbbbbbb");
        System.out.println("Add 'bbbbbbbbbb' to Redis");
        list.add("cccccccccc");
        System.out.println("Add 'cccccccccc' to Redis");

        System.out.println("Get list[0],[1],[2],[3] from Redis: ");
        System.out.println(list.get(0));
        System.out.println(list.get(1));
        System.out.println(list.get(2));
        System.out.println(list.get(3));
        System.out.println("Get done!");

    }
}