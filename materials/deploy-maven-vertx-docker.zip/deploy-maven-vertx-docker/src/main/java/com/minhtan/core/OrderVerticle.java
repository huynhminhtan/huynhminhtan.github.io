package com.minhtan.core;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Vertx;

public class OrderVerticle extends AbstractVerticle {

    private static Vertx vertx = null;

    public static Vertx getInstanceVertX() {

        if (vertx == null) {
            vertx = Vertx.vertx();
            vertx.deployVerticle(new OrderVerticle());
        }

        return vertx;
    }

    public static void main(String[] args) {
        Vertx vertx = getInstanceVertX();
        vertx.deployVerticle(new OrderVerticle());

        System.out.println("He nhu u! : build to fat-jar with maven project ");
    }

}